<?php
/**
* Language file variables. These are used all over the place - menus, paging, searching, templates, newsletters and so on.
*
* @see GetLang
*
* @version     $Id: language.php,v 1.153 2008/02/22 04:45:13 chris Exp $
* @author Chris <chris@localhost>
*
* @package SendStudio
* @subpackage Language
*/

define('LNG_UsersGroups_Field_GroupName', "Nome");
define('LNG_UsersGroups_Field_Permissions', "Permiss&otilde;es");
define('LNG_systemAdminLabel', "Administrador");

define('LNG_UsersGroups_access_lists_custom', "Acesso listas customizado");
define('LNG_UsersGroups_access_lists_all', "Acesso todas as listas");

