<?php
/**
* Language file for upgrade wizard.
* This is here as a placeholder only.
* You can't change the language variables for the sendstudio 2004 -> sendstudionx/iem upgrade wizard.
*
* @package SendStudio
* @subpackage Language
*/

/**
* You can't change the language variables for the upgrade wizard.
*/

?>
